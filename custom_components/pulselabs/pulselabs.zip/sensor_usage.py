# custom_components/pulselabs/sensor_usage.py

from __future__ import annotations

import logging
from homeassistant.components.sensor import SensorEntity, SensorDeviceClass
from homeassistant.const import UnitOfInformation, EntityCategory
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

PLAN_LIMITS = {
    "hobbyist": 4800,
    "enthusiast": 24000,
    "professional": 120000,
}

async def async_setup_entry(hass, entry, async_add_entities):
    coordinator = hass.data[DOMAIN][entry.entry_id]["coordinator"]
    plan = entry.options.get("plan", "hobbyist").lower()
    limit = PLAN_LIMITS.get(plan, 4800)

    entities = [
        DatapointsUsedSensor(coordinator, entry.entry_id),
        DatapointsLimitSensor(coordinator, entry.entry_id, limit, plan),
    ]
    async_add_entities(entities)


class DatapointsUsedSensor(CoordinatorEntity, SensorEntity):
    _attr_has_entity_name = True
    _attr_name = "Datapoints Used Today"
    _attr_icon = "mdi:counter"
    _attr_entity_category = EntityCategory.DIAGNOSTIC
    _attr_native_unit_of_measurement = "datapoints"

    def __init__(self, coordinator, entry_id):
        super().__init__(coordinator)
        self._attr_unique_id = f"{entry_id}_datapoints_used"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, f"api_usage_{entry_id}")},
            name="Pulse API Usage",
            manufacturer="Pulse Labs",
        )

    @property
    def native_value(self):
        return self.coordinator.api.datapoints_today


class DatapointsLimitSensor(CoordinatorEntity, SensorEntity):
    _attr_has_entity_name = True
    _attr_name = "Datapoints Daily Limit"
    _attr_icon = "mdi:chart-line"
    _attr_entity_category = EntityCategory.DIAGNOSTIC
    _attr_native_unit_of_measurement = "datapoints"

    def __init__(self, coordinator, entry_id, limit: int, plan: str):
        super().__init__(coordinator)
        self._limit = limit
        self._plan = plan
        self._attr_unique_id = f"{entry_id}_datapoints_limit"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, f"api_usage_{entry_id}")},
            name="Pulse API Usage",
            manufacturer="Pulse Labs",
        )

    @property
    def native_value(self):
        return self._limit

    @property
    def extra_state_attributes(self):
        used = self.coordinator.api.datapoints_today
        return {
            "remaining": max(0, self._limit - used),
            "plan": self._plan,
        }
