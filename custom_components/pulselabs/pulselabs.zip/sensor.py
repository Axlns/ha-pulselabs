from __future__ import annotations
from typing import Final, Any

from homeassistant.core import HomeAssistant
from homeassistant.config_entries import ConfigEntry
from homeassistant.components.sensor import (
    SensorEntity,
    SensorDeviceClass,
    SensorStateClass
)
from homeassistant.const import (
    UnitOfTemperature,
    UnitOfPressure,
    PERCENTAGE,
    UnitOfElectricPotential,
    CONCENTRATION_PARTS_PER_MILLION
)

from homeassistant.helpers.entity import EntityCategory

from .coordinator import PulseCoordinatorEntity
from .const import DOMAIN, CONF_DEVICES, MANUFACTURER

SENSOR_MAP: Final[dict[str, dict[str, Any]]] = {
    "temperatureF": {
        "translation_key": "temperature",
        "device_class": SensorDeviceClass.TEMPERATURE,
        "unit": UnitOfTemperature.FAHRENHEIT,
    },
    "humidityRh": {
        "translation_key": "humidity",
        "device_class": SensorDeviceClass.HUMIDITY,
        "unit": PERCENTAGE,
    },
    "airPressure": {
        "translation_key": "air_pressure",
        "device_class": SensorDeviceClass.PRESSURE,
        "unit": UnitOfPressure.PA,
    },
    "vpd": {
        "translation_key": "vpd",
        "device_class": None,
        "unit": UnitOfPressure.KPA,
    },
    "vpd_calculated": {
        "translation_key": "lvpd_calculated",
        "device_class": None,
        "unit": UnitOfPressure.KPA,
    },
    "avpd_calculated": {
        "translation_key": "avpd_calculated",
        "device_class": None,
        "unit": UnitOfPressure.KPA,
    },
    "dpF_calculated": {
        "translation_key": "dew_point",
        "device_class": SensorDeviceClass.TEMPERATURE,
        "unit": UnitOfTemperature.FAHRENHEIT,
        "disabled_by_default": True,
    },
    "co2": {
        "translation_key": "co2",
        "device_class": SensorDeviceClass.CO2,
        "unit": CONCENTRATION_PARTS_PER_MILLION,
    },
    "co2Temperature": {
        "translation_key": "co2_temperature",
        "device_class": SensorDeviceClass.TEMPERATURE,
        "unit": UnitOfTemperature.CELSIUS,
        "disabled_by_default": True,
    },
    "co2Rh": {
        "translation_key": "co2_humidity",
        "device_class": SensorDeviceClass.HUMIDITY,
        "unit": PERCENTAGE,
        "disabled_by_default": True,
    },
    "ppfd": {
        "translation_key": "ppfd",
        "device_class": None,
        "unit": "µmol/m²/s",
    },
    "dli": {
        "translation_key": "dli",
        "device_class": None,
        "unit": "mol/m²/d",
    },
    "lightLux": {
        "translation_key": "light",
        "device_class": SensorDeviceClass.ILLUMINANCE,
        "unit": PERCENTAGE,
    },
    "signalStrength": {
        "translation_key": "signal",
        "device_class": SensorDeviceClass.SIGNAL_STRENGTH,
        "unit": "dBm",
    },
    "batteryV": {
        "translation_key": "battery_voltage",
        "device_class": SensorDeviceClass.VOLTAGE,
        "unit": UnitOfElectricPotential.VOLT,
    },
    "api_calls": {
        "translation_key": "api_calls_today",
        "unit": "calls",
        "entity_category": EntityCategory.DIAGNOSTIC,
    },
    "api_forecast": {
        "translation_key": "api_calls_forecast",
        "unit": "calls",
        "entity_category": EntityCategory.DIAGNOSTIC,
    },
}

def build_entities(coordinator, config_entry):
    entities = []

    for device_id, data in coordinator.data.items():
        for key in SENSOR_MAP:
            if key not in data or data[key] is None:
                continue

            spec = SENSOR_MAP[key]
            entity = PulseSensorEntity(
                coordinator=coordinator,
                config_entry=config_entry,
                device_id=device_id,
                key=key,
                t_key=spec.get("translation_key"),
                device_class=spec.get("device_class"),
                unit=spec.get("unit"),
                entity_category=spec.get("entity_category"),
            )

            if spec.get("disabled_by_default"):
                entity._attr_entity_registry_enabled_default = False

            entities.append(entity)

    return entities

async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities) -> None:
    coordinator = hass.data[DOMAIN][entry.entry_id]["coordinator"]
    entities = build_entities(coordinator, entry)
    async_add_entities(entities)

class PulseSensorEntity(PulseCoordinatorEntity, SensorEntity):
    _attr_has_entity_name = True
    _attr_state_class = SensorStateClass.MEASUREMENT

    def __init__(
        self,
        coordinator,
        config_entry,
        device_id,
        key,
        t_key=None,
        device_class=None,
        unit=None,
        entity_category=None,
    ):
        super().__init__(coordinator, config_entry, device_id)
        self._device_id = device_id
        self._api_key = key
        self._attr_unique_id = f"{device_id}_{key}"
        self._attr_device_class = device_class
        self._attr_native_unit_of_measurement = unit
        self._attr_entity_category = entity_category
        if t_key is not None:
            self._attr_translation_key = t_key

    @property
    def native_value(self) -> Any:
        val = self.coordinator.data.get(self._device_id, {}).get(self._api_key)
        return round(val, 2) if isinstance(val, float) else val
