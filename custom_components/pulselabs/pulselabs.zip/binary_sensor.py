from __future__ import annotations
from typing import Final, Any

from homeassistant.components.binary_sensor import (
    BinarySensorEntity,
    BinarySensorDeviceClass,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant

from .coordinator import PulseCoordinatorEntity
from .const import DOMAIN, CONF_DEVICES, MANUFACTURER

BINARY_SENSOR_MAP: Final[dict[str, dict[str, Any]]] = {
    "pluggedIn": {
        "translation_key": "plugged_in",
        "device_class": BinarySensorDeviceClass.PLUG,
        "disabled_by_default": False,
    }
}

def build_entities(coordinator, config_entry):
    entities = []

    for device_id, data in coordinator.data.items():
        for key in BINARY_SENSOR_MAP:
            if key not in data or data[key] is None:
                continue

            spec = BINARY_SENSOR_MAP[key]
            entity = PulseBinarySensorEntity(
                coordinator=coordinator,
                config_entry=config_entry,
                device_id=device_id,
                key=key,
                t_key=spec.get("translation_key"),
                device_class=spec.get("device_class"),
            )

            if spec.get("disabled_by_default"):
                entity._attr_entity_registry_enabled_default = False

            entities.append(entity)

    return entities

async def async_setup_entry(
        hass: HomeAssistant, entry: ConfigEntry, async_add_entities
    ) -> None:
        coordinator = hass.data[DOMAIN][entry.entry_id]["coordinator"]
        entities = build_entities(coordinator, entry)
        async_add_entities(entities)

class PulseBinarySensorEntity(PulseCoordinatorEntity, BinarySensorEntity):
    _attr_has_entity_name = True

    def __init__(
        self,
        coordinator,
        config_entry,
        device_id,
        key,
        t_key=None,
        device_class=None,
    ):
        super().__init__(coordinator, config_entry, device_id)
        self._device_id = device_id
        self._api_key = key
        self._attr_unique_id = f"{device_id}_{key}"
        self._attr_device_class = device_class
        if t_key is not None:
            self._attr_translation_key = t_key
        
    @property
    def is_on(self) -> bool:
        return bool(self.coordinator.data.get(self._device_id, {}).get(self._api_key))

    
