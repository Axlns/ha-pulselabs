from homeassistant.components.binary_sensor import (
    BinarySensorEntity,
    BinarySensorDeviceClass,
)
from homeassistant.helpers.update_coordinator import CoordinatorEntity
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.const import EntityCategory
from homeassistant.helpers.device_registry import DeviceEntryType

from ..const import DOMAIN, MANUFACTURER

class ApiStatusSensor(CoordinatorEntity, BinarySensorEntity):
    _attr_device_class = BinarySensorDeviceClass.CONNECTIVITY
    _attr_has_entity_name = True
    _attr_entity_category = EntityCategory.DIAGNOSTIC
    _attr_translation_key = "api_status"

    def __init__(self, coordinator, entry_id: str):
        super().__init__(coordinator)
        self._attr_unique_id = f"{entry_id}_api_status"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, f"api_usage_{entry_id}")},
            name="Pulse API",
            manufacturer=MANUFACTURER,
            entry_type=DeviceEntryType.SERVICE
        )

    @property
    def is_on(self) -> bool:
        return self.coordinator.last_update_success